listen {{ ansible_all_ipv4_addresses }}:443
NameVirtualHost {{ ansible_fqdn }}

<VirtualHost {{ ansible_fqdn }}:443>
ServerName {{ ansible_fqdn }}
DocumentRoot /var/www/html
SSLEngine on
SSLCertificateFile /etc/httpd/conf.d/ssl/server.crt
SSLCertificateKeyFile /etc/httpd/conf.d/ssl/server.key
</VirtualHost>
