Test roles
